export class Usermodel {
    constructor(public name: string, public email:string, public mobile: number){}
}
